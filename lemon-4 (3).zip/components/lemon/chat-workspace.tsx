"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState, type FormEvent, type KeyboardEvent } from "react"
import { ArrowUpRight, LoaderCircle, MessageSquarePlus, MessageSquareText, Send, Sparkles } from "lucide-react"
import { BOTPRESS_URL } from "@/components/lemon/botpress-widget"
import { createClient } from "@/lib/supabase/client"

type Conversation = { id: string; title: string; updated_at: string }
type Message = { id: string; role: string; content: string; created_at: string }

export function ChatWorkspace({ initialConversations, selectedConversation, initialMessages }: { initialConversations: Conversation[]; selectedConversation: string | null; initialMessages: Message[] }) {
  const router = useRouter()
  const [conversations, setConversations] = useState(initialConversations)
  const [messages, setMessages] = useState(initialMessages)
  const [activeId, setActiveId] = useState(selectedConversation)
  const [draft, setDraft] = useState("")
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState("")
  const activeConversation = conversations.find((item) => item.id === activeId)

  async function createConversation() {
    setBusy(true)
    setNotice("")
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setNotice("Phiên đăng nhập đã hết hạn."); setBusy(false); return }
    const { data, error } = await supabase.from("conversations").insert({ user_id: user.id, title: "Nghiên cứu mới" }).select("id,title,updated_at").single()
    setBusy(false)
    if (error || !data) { setNotice("Không thể tạo cuộc trò chuyện. Vui lòng thử lại."); return }
    setConversations((current) => [data, ...current])
    setMessages([])
    setActiveId(data.id)
    router.replace(`/chat?id=${data.id}`)
  }

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const text = draft.trim()
    if (!text || busy) return
    setBusy(true)
    setNotice("")
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setNotice("Phiên đăng nhập đã hết hạn."); setBusy(false); return }
    let conversationId = activeId
    let conversationTitle = activeConversation?.title ?? ""
    if (!conversationId) {
      const { data, error } = await supabase.from("conversations").insert({ user_id: user.id, title: text.slice(0, 72) }).select("id,title,updated_at").single()
      if (error || !data) { setNotice("Không thể tạo cuộc trò chuyện."); setBusy(false); return }
      conversationId = data.id
      conversationTitle = data.title
      setConversations((current) => [data, ...current])
      setActiveId(data.id)
      router.replace(`/chat?id=${data.id}`)
    }
    const { data: inserted, error } = await supabase.from("messages").insert({ conversation_id: conversationId, user_id: user.id, role: "user", content: text, metadata: { source: "lemon_workspace" } }).select("id,role,content,created_at").single()
    if (error || !inserted) { setNotice("Không thể lưu tin nhắn. Hãy thử lại."); setBusy(false); return }
    const now = new Date().toISOString()
    const nextTitle = conversationTitle === "Nghiên cứu mới" ? text.slice(0, 72) : conversationTitle
    await supabase.from("conversations").update({ title: nextTitle, updated_at: now }).eq("id", conversationId).eq("user_id", user.id)
    setConversations((current) => current.map((item) => item.id === conversationId ? { ...item, title: nextTitle, updated_at: now } : item))
    setMessages((current) => [...current, inserted])
    setDraft("")
    setBusy(false)
  }

  function submitOnEnter(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) {
      event.preventDefault()
      event.currentTarget.form?.requestSubmit()
    }
  }

  return <div>
    <div className="page-heading"><div><span className="page-kicker">LEMON CHAT</span><h1>Chat với Lemon</h1><p>Lưu câu hỏi và ngữ cảnh nghiên cứu trong không gian riêng của bạn.</p></div><a href={BOTPRESS_URL} target="_blank" rel="noopener noreferrer" className="button button-primary button-small">Mở chatbot trực tuyến <ArrowUpRight size={15} /></a></div>
    <div className="chat-layout">
      <aside className="chat-sidebar">
        <div className="chat-sidebar-head"><strong>Cuộc trò chuyện</strong><button className="icon-button" type="button" onClick={() => void createConversation()} aria-label="Tạo cuộc trò chuyện mới" disabled={busy}><MessageSquarePlus size={17} /></button></div>
        <div className="chat-thread-list">{conversations.map((item) => <button className={`chat-thread${item.id === activeId ? " active" : ""}`} type="button" key={item.id} onClick={() => { setActiveId(item.id); router.replace(`/chat?id=${item.id}`); router.refresh() }}><MessageSquareText size={15} /><span className="chat-thread-copy"><strong>{item.title}</strong><small>{new Intl.DateTimeFormat("vi-VN", { day: "numeric", month: "short" }).format(new Date(item.updated_at))}</small></span></button>)}</div>
        <div className="chat-disclaimer">Lịch sử Lemon lưu câu hỏi bạn nhập. Nội dung trả lời từ Botpress chưa được đồng bộ vào tài khoản.</div>
      </aside>
      <section className="chat-main" aria-label="Nội dung hội thoại">
        <header className="chat-main-header"><div><strong>{activeConversation?.title || "Cuộc trò chuyện mới"}</strong><small><span className="status-pill" style={{ padding: "3px 7px", fontSize: 7 }}>Lưu trong tài khoản</span></small></div><Sparkles size={17} color="#9aac75" /></header>
        <div className="chat-message-list" aria-live="polite">
          {messages.length ? messages.map((message) => <div className="chat-bubble" key={message.id}>{message.content}</div>) : <div className="chat-empty"><span className="chat-empty-icon"><MessageSquareText size={21} /></span><strong>Bắt đầu với một câu hỏi văn học</strong><p>Câu hỏi sẽ được lưu theo tài khoản của bạn. Để nhận phản hồi trực tiếp, hãy mở chatbot Botpress; nội dung trả lời của Botpress chưa được đồng bộ vào lịch sử Lemon.</p></div>}
        </div>
        <form className="chat-composer" onSubmit={sendMessage}>
          <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={submitOnEnter} maxLength={4000} placeholder="Nhập câu hỏi hoặc ghi chú nghiên cứu…" aria-label="Tin nhắn" />
          <div className="chat-composer-footer"><small>{notice || "Enter để lưu · Shift + Enter để xuống dòng"}</small><button className="button button-primary button-small" type="submit" disabled={busy || !draft.trim()}>{busy ? <LoaderCircle size={15} className="spin" /> : <Send size={14} />} Lưu câu hỏi</button></div>
        </form>
      </section>
    </div>
  </div>
}
