"use client"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, FileText, LoaderCircle, Save, Trash2 } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { SavedAnalysis } from "@/components/lemon/analysis-library"

export function AnalysisDetail({ analysis }: { analysis: SavedAnalysis }) {
  const [title, setTitle] = useState(analysis.title)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState("")
  const router = useRouter()
  const content = analysis.content && typeof analysis.content === "object" ? analysis.content as Record<string, unknown> : {}
  const notes = typeof content.draft_text === "string" ? content.draft_text : ""
  const selectedSections = Array.isArray(content.selected_sections) ? content.selected_sections.filter((item): item is string => typeof item === "string") : []

  async function saveTitle() {
    setBusy(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setMessage("Phiên đăng nhập đã hết hạn."); setBusy(false); return }
    const { error } = await supabase.from("saved_analyses").update({ title: title.trim().slice(0, 180), updated_at: new Date().toISOString() }).eq("id", analysis.id).eq("user_id", user.id)
    setBusy(false)
    setMessage(error ? "Không thể cập nhật tiêu đề." : "Tiêu đề đã được cập nhật.")
  }

  async function remove() {
    if (!window.confirm("Xóa bài phân tích này khỏi thư viện cá nhân?")) return
    setBusy(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setBusy(false); return }
    const { error } = await supabase.from("saved_analyses").delete().eq("id", analysis.id).eq("user_id", user.id)
    setBusy(false)
    if (error) setMessage("Không thể xóa bài phân tích.")
    else router.replace("/my-analyses")
  }

  return <div>
    <div className="page-heading"><div><Link href="/my-analyses" className="subtle-link"><ArrowLeft size={14} /> Bài phân tích của tôi</Link><span className="page-kicker" style={{ display: "block", marginTop: 14 }}>BẢN NHÁP NGHIÊN CỨU</span><h1>{analysis.work_title || "Bản nháp nghiên cứu"}</h1><p>{analysis.author_name || "Chưa ghi tên tác giả"} · Cập nhật {new Intl.DateTimeFormat("vi-VN", { dateStyle: "medium" }).format(new Date(analysis.updated_at))}</p></div><button className="button button-quiet button-small" type="button" onClick={() => window.print()}><FileText size={15} /> In / lưu PDF</button></div>
    <div className="tool-layout">
      <section className="tool-form-card card-surface">
        <div className="card-heading"><div><h2>Tiêu đề bài phân tích</h2><p>Bạn có thể đổi tên bản nháp bất cứ lúc nào.</p></div></div>
        <div className="tool-form"><label className="form-field"><span>Tiêu đề</span><input className="text-input" value={title} onChange={(event) => setTitle(event.target.value)} maxLength={180} /></label><div className="tool-submit-row"><button className="button button-primary button-small" type="button" onClick={() => void saveTitle()} disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <Save size={15} />} Lưu tiêu đề</button><button className="small-action danger" type="button" onClick={() => void remove()} disabled={busy}><Trash2 size={14} /> Xóa bài</button></div>{message && <p className="form-notice success" role="status">{message}</p>}</div>
        <div style={{ marginTop: 25 }}><h2 style={{ color: "var(--ink)", fontSize: 13 }}>Ghi chú nghiên cứu</h2>{notes ? <p style={{ color: "var(--muted)", fontSize: 11, whiteSpace: "pre-wrap", lineHeight: 1.8 }}>{notes}</p> : <div className="muted-note">Bản nháp này chưa có ghi chú. Lemon chưa tạo nội dung phân tích tự động.</div>}</div>
      </section>
      <aside className="dashboard-column"><section className="tool-side-card card-surface"><div className="card-heading"><div><h3>Các mục đã chọn</h3><p>Khung nội dung của bản nháp.</p></div></div>{selectedSections.length ? <ul className="tool-section-list">{selectedSections.map((section) => <li key={section}><span>✓</span>{section}</li>)}</ul> : <p className="muted-note">Chưa chọn mục phân tích.</p>}</section><div className="api-status-card"><div className="api-status-header"><span><FileText size={15} /></span> Trạng thái nội dung</div><p>Đây là bản nháp do bạn lưu. Không có câu trả lời AI hoặc nguồn dẫn nào được tạo trong bản ghi này.</p></div></aside>
    </div>
  </div>
}
