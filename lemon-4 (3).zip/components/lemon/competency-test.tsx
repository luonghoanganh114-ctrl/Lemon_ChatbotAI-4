"use client"

import { useMemo, useRef, useState } from "react"
import { ArrowRight, CheckCircle2, RotateCcw, Sparkles } from "lucide-react"

const questions = [
  { id: 1, prompt: "Trong đoạn trích tự sự, chi tiết nào thường có vai trò làm nổi bật tính cách nhân vật?", options: ["Chi tiết nghệ thuật", "Lời giới thiệu tác giả", "Tên nhà xuất bản", "Số trang tác phẩm"], answer: 0 },
  { id: 2, prompt: "Hình ảnh ‘con thuyền’ trong thơ ca thường có thể gợi liên tưởng đến điều gì?", options: ["Hành trình và khát vọng", "Một phép tính", "Tên thể loại văn bản", "Quy tắc gieo vần"], answer: 0 },
  { id: 3, prompt: "Biện pháp tu từ nào được sử dụng trong câu: ‘Mặt trời xuống biển như hòn lửa’?", options: ["So sánh", "Điệp ngữ", "Hoán dụ", "Nói giảm"], answer: 0 },
  { id: 4, prompt: "Luận điểm trong một bài nghị luận văn học là gì?", options: ["Ý kiến chính cần được làm sáng tỏ", "Một câu trích dẫn bất kỳ", "Danh sách tài liệu", "Phần mở đầu tác phẩm"], answer: 0 },
  { id: 5, prompt: "Yếu tố nào giúp lời văn có sức thuyết phục hơn?", options: ["Lý lẽ và dẫn chứng phù hợp", "Dùng thật nhiều từ khó", "Viết toàn bộ bằng câu hỏi", "Lặp lại một ý nhiều lần"], answer: 0 },
  { id: 6, prompt: "Điểm nhìn trần thuật ‘ngôi thứ nhất’ thường được nhận biết qua cách xưng hô nào?", options: ["Tôi / chúng tôi", "Hắn / nó", "Anh ấy / cô ấy", "Họ / người ta"], answer: 0 },
  { id: 7, prompt: "Khi phân tích một hình tượng văn học, thao tác phù hợp nhất là gì?", options: ["Kết hợp dẫn chứng với nhận xét", "Chỉ kể lại cốt truyện", "Chỉ nêu cảm xúc cá nhân", "Bỏ qua hoàn cảnh sáng tác"], answer: 0 },
  { id: 8, prompt: "Một kết luận tốt trong bài nghị luận nên làm gì?", options: ["Khái quát và mở rộng ý nghĩa vấn đề", "Đưa thêm một luận điểm chưa giải thích", "Chép lại toàn bộ mở bài", "Kể một câu chuyện không liên quan"], answer: 0 },
  { id: 9, prompt: "Tác dụng chính của phép điệp trong thơ thường là gì?", options: ["Tạo nhịp điệu và nhấn mạnh ý", "Giới thiệu tác giả", "Thay đổi ngôi kể", "Xác định thể loại"], answer: 0 },
  { id: 10, prompt: "Khi đọc một văn bản thông tin, thao tác đầu tiên nên là gì?", options: ["Xác định chủ đề và mục đích văn bản", "Học thuộc mọi con số", "Bỏ qua nhan đề", "Chỉ tìm từ đồng nghĩa"], answer: 0 },
  { id: 11, prompt: "Hình ảnh thơ có sức gợi thường kết hợp giữa yếu tố nào?", options: ["Tả thực và liên tưởng", "Số liệu và công thức", "Tiêu đề và mục lục", "Chú thích và phụ lục"], answer: 0 },
  { id: 12, prompt: "Một dẫn chứng tốt trong bài nghị luận cần có đặc điểm nào?", options: ["Tiêu biểu và được phân tích đúng ngữ cảnh", "Càng dài càng tốt", "Không cần liên quan luận điểm", "Chỉ lấy từ mạng xã hội"], answer: 0 },
  { id: 13, prompt: "Không gian nghệ thuật góp phần thể hiện điều gì?", options: ["Tâm trạng và thế giới của nhân vật", "Số lượng chương sách", "Tên người biên tập", "Giá bìa tác phẩm"], answer: 0 },
  { id: 14, prompt: "Câu hỏi tu từ thường được dùng để làm gì?", options: ["Gợi suy nghĩ và nhấn mạnh cảm xúc", "Yêu cầu người đọc trả lời bắt buộc", "Kết thúc mọi đoạn văn", "Thay thế dẫn chứng"], answer: 0 },
  { id: 15, prompt: "Mạch cảm xúc trong một bài thơ là gì?", options: ["Sự vận động của cảm xúc qua các phần thơ", "Số chữ trong mỗi câu", "Danh sách hình ảnh", "Thứ tự xuất bản"], answer: 0 },
  { id: 16, prompt: "Muốn nhận xét nhân vật thuyết phục, người viết nên dựa vào đâu?", options: ["Hành động, lời nói và hoàn cảnh của nhân vật", "Sở thích riêng của người viết", "Tên chương truyện", "Độ dài văn bản"], answer: 0 },
  { id: 17, prompt: "Nhan đề của tác phẩm thường có thể gợi ra điều gì?", options: ["Chủ đề hoặc hướng tiếp cận tác phẩm", "Năm sinh của nhân vật", "Số lượng đoạn văn", "Tên người in sách"], answer: 0 },
  { id: 18, prompt: "Giọng điệu trữ tình được nhận biết rõ nhất qua yếu tố nào?", options: ["Cách bộc lộ cảm xúc và thái độ", "Số trang của văn bản", "Danh sách nhân vật", "Kích thước sách"], answer: 0 },
  { id: 19, prompt: "Trong văn nghị luận, phản đề giúp người viết làm gì?", options: ["Nhìn nhận và bác bỏ quan điểm chưa phù hợp", "Kể lại toàn bộ câu chuyện", "Thay thế phần kết luận", "Tạo thêm nhân vật"], answer: 0 },
  { id: 20, prompt: "Phép ẩn dụ dựa trên mối quan hệ nào giữa các sự vật?", options: ["Tương đồng", "Đối lập hoàn toàn", "Trình tự thời gian", "Quan hệ số lượng"], answer: 0 },
  { id: 21, prompt: "Chi tiết kết thúc bất ngờ thường có tác dụng gì trong truyện?", options: ["Tạo ấn tượng và làm nổi bật ý nghĩa", "Xóa bỏ chủ đề", "Giới thiệu tác giả", "Thay thế nhan đề"], answer: 0 },
  { id: 22, prompt: "Khi tóm tắt văn bản, điều gì cần được ưu tiên?", options: ["Sự kiện chính và trình tự hợp lý", "Mọi lời thoại nhỏ", "Cảm xúc ngoài văn bản", "Nhận xét về bìa sách"], answer: 0 },
  { id: 23, prompt: "Tính hàm súc của ngôn ngữ văn học là khả năng gì?", options: ["Gợi nhiều ý nghĩa bằng hình thức cô đọng", "Dùng càng nhiều từ càng tốt", "Chỉ mô tả sự việc trực tiếp", "Không sử dụng hình ảnh"], answer: 0 },
  { id: 24, prompt: "Để chuyển từ phân tích sang nhận xét, người viết cần làm gì?", options: ["Khái quát ý nghĩa từ các chi tiết đã phân tích", "Đổi sang kể chuyện khác", "Bỏ toàn bộ dẫn chứng", "Lặp lại nguyên văn đề bài"], answer: 0 },
]

function shuffle<T>(items: T[]) {
  const copy = [...items]
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1))
    ;[copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]]
  }
  return copy
}

function buildTest(excludedIds: number[] = []) {
  const availableQuestions = questions.filter((question) => !excludedIds.includes(question.id))
  const questionPool = availableQuestions.length >= 8 ? availableQuestions : questions
  return shuffle(questionPool).slice(0, 8).map((question) => {
    const options = shuffle(question.options.map((text, index) => ({ text, correct: index === question.answer })))
    return { ...question, options, answer: options.findIndex((option) => option.correct) }
  })
}

function levelFor(score: number) {
  if (score >= 7) return { label: "Tốt", tone: "strong", detail: "Bạn nắm chắc kiến thức đọc hiểu và tư duy nghị luận cơ bản." }
  if (score >= 5) return { label: "Khá", tone: "good", detail: "Bạn có nền tảng ổn; hãy luyện thêm cách phân tích dẫn chứng và lập luận." }
  if (score >= 3) return { label: "Đang phát triển", tone: "developing", detail: "Bạn đã có những điểm nắm đúng; nên ôn lại biện pháp tu từ và cấu trúc nghị luận." }
  return { label: "Cần củng cố", tone: "needs-work", detail: "Lemon khuyên bạn bắt đầu từ đọc hiểu, thuật ngữ cơ bản và cách tìm luận điểm." }
}

export function CompetencyTest() {
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [submitted, setSubmitted] = useState(false)
  const [testVersion, setTestVersion] = useState(0)
  const [usedQuestionIds, setUsedQuestionIds] = useState<number[]>([])
  const previousTestSignature = useRef("")
  const testQuestions = useMemo(() => {
    let nextTest = buildTest(usedQuestionIds)
    let signature = nextTest.map((question) => `${question.id}:${question.answer}:${question.options.map((option) => option.text).join("|")}`).join("/")
    while (signature === previousTestSignature.current) {
      nextTest = buildTest()
      signature = nextTest.map((question) => `${question.id}:${question.answer}:${question.options.map((option) => option.text).join("|")}`).join("/")
    }
    previousTestSignature.current = signature
    return nextTest
  }, [testVersion, usedQuestionIds])
  const score = useMemo(() => testQuestions.reduce((total, question) => total + (answers[question.id] === question.answer ? 1 : 0), 0), [answers, testQuestions])
  const level = levelFor(score)

  function submit() { if (Object.keys(answers).length === testQuestions.length) setSubmitted(true) }
  function askLemon() {
    window.dispatchEvent(new CustomEvent("lemon:open-chat", {
      detail: {
        source: "competency-test",
        score,
        total: testQuestions.length,
        level: level.label,
        answers,
        questions: testQuestions.map(({ id, prompt, options, answer }) => ({ id, prompt, selected: answers[id], selectedText: options[answers[id]]?.text, correctText: options[answer]?.text })),
      },
    }))
  }

  if (submitted) return (
    <div className="competency-page">
      <div className="page-heading"><div><span className="page-kicker">LEMON COMPETENCY LAB</span><h1>Kết quả bài thi</h1><p>Lemon đã chấm bài theo 8 câu hỏi ngữ văn ở mức độ trung bình.</p></div><button className="button button-quiet button-small" type="button" onClick={() => { setSubmitted(false); setAnswers({}); setUsedQuestionIds((used) => [...new Set([...used, ...testQuestions.map((question) => question.id)])]); setTestVersion((version) => version + 1) }}><RotateCcw size={14} /> Làm lại</button></div>
      <section className="competency-result card-surface">
        <div className={`competency-score ${level.tone}`}><strong>{score}<small>/8</small></strong><span>câu đúng</span></div>
        <div className="competency-result-copy"><span className="page-kicker">ĐÁNH GIÁ NĂNG LỰC</span><h2>Mức độ: {level.label}</h2><p>{level.detail}</p><div className="competency-meter"><span style={{ width: `${(score / testQuestions.length) * 100}%` }} /></div><small>Điểm được dùng để định hướng học tập, không thay thế đánh giá chính thức.</small></div>
      </section>
      <section className="competency-review" aria-labelledby="review-title">
        <div className="review-heading"><div><span className="page-kicker">ĐÁP ÁN CHI TIẾT</span><h2 id="review-title">Bạn làm đúng và sai câu nào?</h2></div><span>{score}/{testQuestions.length} câu đúng</span></div>
        <div className="review-list">{testQuestions.map((question, index) => { const isCorrect = answers[question.id] === question.answer; return <article className={`review-item ${isCorrect ? "correct" : "incorrect"}`} key={question.id}><div className="review-status" aria-label={isCorrect ? "Đúng" : "Sai"}>{isCorrect ? "ĐÚNG" : "SAI"}</div><div className="review-content"><strong>Câu {index + 1}. {question.prompt}</strong><span>Lựa chọn của bạn: <b>{question.options[answers[question.id]]?.text}</b></span>{!isCorrect && <span>Đáp án đúng: <b>{question.options[question.answer]?.text}</b></span>}</div></article> })}</div>
      </section>
      <section className="competency-next card-surface"><div><span className="feature-icon yellow"><Sparkles size={17} /></span><h2>Muốn nghe Lemon phân tích kỹ hơn?</h2><p>Mở chatbot để nhận gợi ý ôn tập cá nhân hóa dựa trên kết quả vừa làm.</p></div><button className="button button-primary" type="button" onClick={askLemon}>Hỏi Lemon về kết quả <ArrowRight size={15} /></button></section>
    </div>
  )

  return (
    <div className="competency-page">
      <div className="page-heading"><div><span className="page-kicker">LEMON COMPETENCY LAB</span><h1>Test năng lực Ngữ văn</h1><p>8 câu hỏi mức độ trung bình · Chọn đáp án phù hợp nhất với bạn.</p></div><span className="competency-progress">{Object.keys(answers).length}/{testQuestions.length} câu</span></div>
      <form className="competency-form" onSubmit={(event) => { event.preventDefault(); submit() }}>
        {testQuestions.map((question, index) => <fieldset className="competency-question card-surface" key={question.id}><legend><span>{String(index + 1).padStart(2, "0")}</span>{question.prompt}</legend><div className="competency-options">{question.options.map((option, optionIndex) => <label key={option.text}><input type="radio" name={`question-${question.id}`} checked={answers[question.id] === optionIndex} onChange={() => setAnswers((current) => ({ ...current, [question.id]: optionIndex }))} /><span>{option.text}</span></label>)}</div></fieldset>)}
        <div className="competency-submit"><button className="button button-primary" type="submit" disabled={Object.keys(answers).length !== testQuestions.length}><CheckCircle2 size={16} /> Nộp bài và nhận đánh giá</button>{Object.keys(answers).length !== testQuestions.length && <span>Hãy trả lời đủ {testQuestions.length} câu để Lemon chấm bài.</span>}</div>
      </form>
    </div>
  )
}
