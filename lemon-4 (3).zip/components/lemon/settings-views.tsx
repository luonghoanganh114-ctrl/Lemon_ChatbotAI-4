"use client"

import Link from "next/link"
import { useState, type FormEvent } from "react"
import { useRouter } from "next/navigation"
import { ArrowRight, Bell, KeyRound, LoaderCircle, Moon, ShieldCheck, UserRound } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

export function SettingsView() {
  const links = [
    { title: "Hồ sơ cá nhân", copy: "Tên hiển thị, ảnh đại diện và sở thích nghiên cứu.", href: "/profile", icon: UserRound },
    { title: "Bảo mật tài khoản", copy: "Đổi mật khẩu và xem các tùy chọn đăng nhập.", href: "/settings/security", icon: ShieldCheck },
  ]
  return <div><div className="page-heading"><div><span className="page-kicker">TÙY CHỈNH KHÔNG GIAN</span><h1>Cài đặt</h1><p>Quản lý hồ sơ, bảo mật và trải nghiệm Lemon của bạn.</p></div></div><div className="settings-list">{links.map(({ title, copy, href, icon: Icon }) => <Link href={href} className="settings-row" key={title}><span className="settings-row-icon"><Icon size={18} /></span><span className="settings-row-copy"><strong>{title}</strong><small>{copy}</small></span><ArrowRight size={16} color="#9ba6b3" /></Link>)}<div className="settings-row"><span className="settings-row-icon"><Moon size={17} /></span><span className="settings-row-copy"><strong>Giao diện sáng / tối</strong><small>Đổi giao diện bằng biểu tượng mặt trăng trên thanh điều hướng.</small></span></div><div className="settings-row"><span className="settings-row-icon"><Bell size={17} /></span><span className="settings-row-copy"><strong>Thông báo email</strong><small>Thông báo xác nhận và khôi phục được gửi qua Supabase Auth.</small></span></div></div></div>
}

export function SecurityForm() {
  const router = useRouter()
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const currentPassword = String(data.get("currentPassword") ?? "")
    const newPassword = String(data.get("newPassword") ?? "")
    const confirmation = String(data.get("confirmation") ?? "")
    setNotice(null)
    if (newPassword.length < 8) { setNotice({ tone: "error", text: "Mật khẩu mới cần có ít nhất 8 ký tự." }); return }
    if (newPassword !== confirmation) { setNotice({ tone: "error", text: "Hai mật khẩu mới chưa trùng khớp." }); return }
    setBusy(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user?.email) { setNotice({ tone: "error", text: "Không thể xác minh tài khoản." }); setBusy(false); return }
    const { error: verifyError } = await supabase.auth.signInWithPassword({ email: user.email, password: currentPassword })
    if (verifyError) { setNotice({ tone: "error", text: "Mật khẩu hiện tại không chính xác." }); setBusy(false); return }
    const { error } = await supabase.auth.updateUser({ password: newPassword })
    setBusy(false)
    if (error) { setNotice({ tone: "error", text: "Không thể cập nhật mật khẩu. Vui lòng thử lại." }); return }
    setNotice({ tone: "success", text: "Mật khẩu đã được cập nhật an toàn." })
    event.currentTarget.reset()
    router.refresh()
  }

  return <div><div className="page-heading"><div><span className="page-kicker">BẢO MẬT TÀI KHOẢN</span><h1>Đổi mật khẩu</h1><p>Xác minh mật khẩu hiện tại trước khi thay đổi thông tin đăng nhập.</p></div></div><section className="profile-card card-surface" style={{ maxWidth: 640 }}><div className="card-heading"><div><h2><KeyRound size={16} style={{ verticalAlign: "middle", marginRight: 7 }} />Cập nhật mật khẩu</h2><p>Mật khẩu được Supabase Auth xử lý; Lemon không lưu bản rõ.</p></div></div><form className="tool-form" onSubmit={submit}><label className="form-field"><span>Mật khẩu hiện tại</span><input className="text-input" type="password" name="currentPassword" autoComplete="current-password" required /></label><label className="form-field"><span>Mật khẩu mới</span><input className="text-input" type="password" name="newPassword" minLength={8} autoComplete="new-password" required /></label><label className="form-field"><span>Xác nhận mật khẩu mới</span><input className="text-input" type="password" name="confirmation" minLength={8} autoComplete="new-password" required /></label>{notice && <p className={`form-notice ${notice.tone}`} role="status">{notice.text}</p>}<div className="tool-submit-row"><button type="submit" className="button button-primary button-small" disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <ShieldCheck size={15} />} Cập nhật mật khẩu</button></div></form></section></div>
}

export function UnavailableView({ title, description }: { title: string; description: string }) {
  return <div><div className="page-heading"><div><span className="page-kicker">LEMON KNOWLEDGE</span><h1>{title}</h1><p>{description}</p></div></div><section className="card-surface empty-state" style={{ minHeight: 260 }}><span className="empty-state-icon"><KeyRound size={20} /></span><strong>Chưa kết nối nguồn dữ liệu</strong><p>Không hiển thị dữ liệu văn học giả. Kết nối cơ sở dữ liệu nguồn hoặc dịch vụ tra cứu để bật tìm kiếm và xác minh tại đây.</p></section><div className="muted-note" style={{ marginTop: 13 }}>Bạn vẫn có thể tạo bản nháp nghiên cứu, lưu ghi chú và tiếp tục theo dõi câu hỏi trong không gian cá nhân.</div></div>
}
