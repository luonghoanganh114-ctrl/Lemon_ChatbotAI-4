"use client"

import { useState, type FormEvent, type ChangeEvent } from "react"
import { CalendarDays, ImagePlus, LoaderCircle, Save, ShieldCheck, UserRound } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

type Profile = { full_name: string; bio: string; interests: unknown; avatar_url: string | null; created_at: string }

export function ProfileForm({ profile, email, createdAt, avatarUrl }: { profile: Profile | null; email: string; createdAt: string; avatarUrl: string | null }) {
  const [name, setName] = useState(profile?.full_name ?? "")
  const [bio, setBio] = useState(profile?.bio ?? "")
  const [interests, setInterests] = useState(Array.isArray(profile?.interests) ? profile.interests.filter((value): value is string => typeof value === "string").join(", ") : "")
  const [emailDraft, setEmailDraft] = useState(email)
  const [imageUrl, setImageUrl] = useState(avatarUrl)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null)

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setBusy(true)
    setNotice(null)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setNotice({ tone: "error", text: "Phiên đăng nhập đã hết hạn." }); setBusy(false); return }
    const { error } = await supabase.from("profiles").upsert({
      id: user.id,
      full_name: name.trim().slice(0, 80),
      bio: bio.trim().slice(0, 600),
      interests: interests.split(",").map((value) => value.trim()).filter(Boolean).slice(0, 20),
      avatar_url: profile?.avatar_url ?? null,
      updated_at: new Date().toISOString(),
    }, { onConflict: "id" })
    setBusy(false)
    setNotice(error ? { tone: "error", text: "Không thể lưu hồ sơ. Vui lòng thử lại." } : { tone: "success", text: "Hồ sơ đã được cập nhật." })
  }

  async function uploadAvatar(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    setNotice(null)
    if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) {
      setNotice({ tone: "error", text: "Chọn ảnh định dạng hình ảnh, dung lượng tối đa 5 MB." })
      event.target.value = ""
      return
    }
    setBusy(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setNotice({ tone: "error", text: "Phiên đăng nhập đã hết hạn." }); setBusy(false); return }
    const extension = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg"
    const path = `${user.id}/${crypto.randomUUID()}.${extension}`
    const { error: uploadError } = await supabase.storage.from("lemon-avatars").upload(path, file, { contentType: file.type, upsert: false })
    if (uploadError) {
      setNotice({ tone: "error", text: "Không thể tải ảnh lên. Hãy kiểm tra bucket lemon-avatars và chính sách Storage." })
      setBusy(false)
      return
    }
    const { error: updateError } = await supabase.from("profiles").upsert({ id: user.id, full_name: name.trim(), bio: bio.trim(), interests: interests.split(",").map((value) => value.trim()).filter(Boolean), avatar_url: path, updated_at: new Date().toISOString() }, { onConflict: "id" })
    if (updateError) {
      await supabase.storage.from("lemon-avatars").remove([path])
      setNotice({ tone: "error", text: "Ảnh đã tải lên nhưng chưa lưu được hồ sơ. Vui lòng thử lại." })
      setBusy(false)
      return
    }
    const { data: signed } = await supabase.storage.from("lemon-avatars").createSignedUrl(path, 60 * 60)
    setImageUrl(signed?.signedUrl ?? null)
    setNotice({ tone: "success", text: "Ảnh đại diện đã được cập nhật." })
    setBusy(false)
    event.target.value = ""
  }

  async function requestEmailChange() {
    if (!emailDraft.trim() || emailDraft.trim().toLowerCase() === email.toLowerCase()) return
    setBusy(true)
    const { error } = await createClient().auth.updateUser({ email: emailDraft.trim().toLowerCase() })
    setBusy(false)
    setNotice(error ? { tone: "error", text: "Không thể yêu cầu đổi email. Hãy thử lại sau." } : { tone: "success", text: "Đã gửi yêu cầu xác nhận đến địa chỉ email mới. Email hiện tại chỉ thay đổi sau khi xác nhận." })
  }

  const initial = (name.trim()[0] || email[0] || "L").toUpperCase()
  return <div className="profile-layout">
    <section className="profile-card card-surface">
      <div className="card-heading"><div><h2>Thông tin cá nhân</h2><p>Hồ sơ này chỉ hiển thị trong không gian Lemon của bạn.</p></div><ShieldCheck size={18} color="#83b96a" /></div>
      <form onSubmit={saveProfile}>
        <div className="profile-avatar-row" style={{ marginTop: 18 }}>
          {imageUrl ? <img className="profile-avatar" src={imageUrl} alt="Ảnh đại diện của bạn" /> : <span className="profile-avatar"><UserRound size={28} /></span>}
          <div className="profile-avatar-actions"><label className="small-action" htmlFor="avatar-upload"><ImagePlus size={14} /> Thay ảnh đại diện</label><input id="avatar-upload" type="file" accept="image/*" onChange={uploadAvatar} hidden /><p>PNG, JPG hoặc WebP · tối đa 5 MB</p></div>
        </div>
        <div className="profile-fields">
          <label className="form-field"><span>Họ và tên</span><input className="text-input" value={name} onChange={(event) => setName(event.target.value)} maxLength={80} required /></label>
          <label className="form-field"><span>Email đăng ký</span><input className="text-input" type="email" value={emailDraft} onChange={(event) => setEmailDraft(event.target.value)} disabled={busy} /></label>
          <label className="form-field full-width"><span>Giới thiệu</span><textarea className="textarea-input" value={bio} onChange={(event) => setBio(event.target.value)} maxLength={600} placeholder="Một vài dòng về hành trình đọc và nghiên cứu của bạn…" /></label>
          <label className="form-field full-width"><span>Sở thích nghiên cứu</span><input className="text-input" value={interests} onChange={(event) => setInterests(event.target.value)} maxLength={400} placeholder="Thơ ca, văn học hiện đại, chủ nghĩa hiện thực…" /><small style={{ color: "#9aa4b1", fontSize: 9 }}>Phân tách bằng dấu phẩy.</small></label>
        </div>
        {notice && <p className={`form-notice ${notice.tone}`} role="status" style={{ marginTop: 14 }}>{notice.text}</p>}
        <div className="tool-submit-row" style={{ marginTop: 16 }}><button type="submit" className="button button-primary button-small" disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <Save size={15} />} Lưu hồ sơ</button><button type="button" className="button button-quiet button-small" onClick={() => void requestEmailChange()} disabled={busy || emailDraft.trim().toLowerCase() === email.toLowerCase()}>Yêu cầu đổi email</button></div>
      </form>
    </section>
    <aside className="dashboard-column"><section className="tool-side-card card-surface"><div className="card-heading"><div><h3>Tài khoản</h3><p>Thông tin xác thực do Supabase Auth quản lý.</p></div></div><div className="profile-meta"><div className="profile-meta-row"><span>Email hiện tại</span><strong>{email}</strong></div><div className="profile-meta-row"><span>Ngày tham gia</span><strong>{new Intl.DateTimeFormat("vi-VN", { dateStyle: "medium" }).format(new Date(profile?.created_at || createdAt))}</strong></div><div className="profile-meta-row"><span>ID tài khoản</span><strong>Ẩn vì lý do bảo mật</strong></div></div></section><div className="muted-note"><CalendarDays size={14} style={{ verticalAlign: "middle", marginRight: 6 }} />Email mới chỉ được áp dụng sau khi bạn xác nhận qua email. Lemon không cho phép chỉnh sửa ID tài khoản.</div></aside>
  </div>
}
