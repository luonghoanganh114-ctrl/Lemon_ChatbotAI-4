"use client"

import Link from "next/link"
import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowRight, BookOpenCheck, CalendarDays, Clock3, FileText, LoaderCircle, Search, Trash2 } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

export type SavedAnalysis = { id: string; title: string; work_title: string; author_name: string; analysis_mode: string; tags: string[]; content: unknown; created_at: string; updated_at: string }

const formatDate = (value: string) => new Intl.DateTimeFormat("vi-VN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value))

export function AnalysisLibrary({ initial, initialQuery = "" }: { initial: SavedAnalysis[]; initialQuery?: string }) {
  const [items, setItems] = useState(initial)
  const [query, setQuery] = useState(initialQuery)
  const [author, setAuthor] = useState("")
  const [month, setMonth] = useState("")
  const [deleting, setDeleting] = useState<string | null>(null)
  const router = useRouter()
  const authors = useMemo(() => Array.from(new Set(items.map((item) => item.author_name.trim()).filter(Boolean))), [items])
  const filtered = useMemo(() => items.filter((item) => {
    const search = `${item.title} ${item.work_title} ${item.author_name}`.toLocaleLowerCase()
    const matchesQuery = search.includes(query.trim().toLocaleLowerCase())
    const matchesAuthor = !author || item.author_name === author
    const matchesMonth = !month || item.updated_at.slice(0, 7) === month
    return matchesQuery && matchesAuthor && matchesMonth
  }), [items, query, author, month])

  async function remove(id: string) {
    if (!window.confirm("Xóa bài phân tích này khỏi thư viện cá nhân?")) return
    setDeleting(id)
    const { data: { user } } = await createClient().auth.getUser()
    if (!user) { setDeleting(null); return }
    const { error } = await createClient().from("saved_analyses").delete().eq("id", id).eq("user_id", user.id)
    setDeleting(null)
    if (!error) setItems((current) => current.filter((item) => item.id !== id))
  }

  function exportPdf() { window.print() }

  return (
    <>
      <div className="page-heading"><div><span className="page-kicker">THƯ VIỆN CÁ NHÂN</span><h1>Bài phân tích của tôi</h1><p>Các bản nháp và nghiên cứu được lưu trong tài khoản của bạn.</p></div><Link href="/tools/analysis" className="button button-primary button-small"><BookOpenCheck size={15} /> Bắt đầu nghiên cứu</Link></div>
      <div className="list-toolbar">
        <label className="list-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Tìm theo tác phẩm, tác giả hoặc tiêu đề" aria-label="Tìm bài phân tích" /></label>
        <select className="select-input" value={author} onChange={(event) => setAuthor(event.target.value)} aria-label="Lọc theo tác giả"><option value="">Tất cả tác giả</option>{authors.map((item) => <option key={item} value={item}>{item}</option>)}</select>
        <label className="list-search" style={{ flex: "0 0 auto", minWidth: 155 }}><CalendarDays size={15} /><input type="month" value={month} onChange={(event) => setMonth(event.target.value)} aria-label="Lọc theo tháng cập nhật" /></label>
        <span className="status-pill">{filtered.length} bản nháp</span>
      </div>
      {filtered.length ? <div className="analysis-grid">{filtered.map((item) => <article className="analysis-card card-surface" key={item.id}>
        <div className="analysis-card-top"><span className="status-pill">Bản nháp</span><button className="icon-button" type="button" onClick={() => void remove(item.id)} aria-label={`Xóa ${item.title}`} disabled={deleting === item.id}>{deleting === item.id ? <LoaderCircle size={16} className="spin" /> : <Trash2 size={15} />}</button></div>
        <h3>{item.title}</h3><p>{item.work_title || "Chưa ghi tên tác phẩm"}{item.author_name ? ` · ${item.author_name}` : ""}</p>
        <div className="analysis-card-footer"><span><Clock3 size={12} /> Cập nhật {formatDate(item.updated_at)}</span><div className="analysis-actions"><button className="small-action" onClick={exportPdf} type="button"><FileText size={13} /> In / PDF</button><Link className="small-action" href={`/my-analyses/${item.id}`}>Mở <ArrowRight size={13} /></Link></div></div>
      </article>)}</div> : <section className="card-surface empty-state"><span className="empty-state-icon"><BookOpenCheck size={19} /></span><strong>{items.length ? "Không tìm thấy bài phù hợp" : "Thư viện của bạn đang trống"}</strong><p>{items.length ? "Thử đổi từ khóa hoặc bộ lọc." : "Lưu một bản nháp từ công cụ nghiên cứu để bắt đầu xây dựng thư viện cá nhân."}</p>{!items.length && <Link href="/tools/analysis" className="subtle-link">Tạo bản nháp đầu tiên <ArrowRight size={13} /></Link>}</section>}
    </>
  )
}
