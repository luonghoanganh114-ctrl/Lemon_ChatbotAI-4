import Link from "next/link"
import { ArrowRight, BookOpenCheck, MessageSquareText } from "lucide-react"

type Item = { id: string; title: string; updated_at: string }

export function HistoryView({ analyses, conversations }: { analyses: Item[]; conversations: Item[] }) {
  const events = [
    ...analyses.map((item) => ({ ...item, kind: "analysis" as const })),
    ...conversations.map((item) => ({ ...item, kind: "conversation" as const })),
  ].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
  return <div><div className="page-heading"><div><span className="page-kicker">DÒNG THỜI GIAN CÁ NHÂN</span><h1>Lịch sử nghiên cứu</h1><p>Các bài phân tích và cuộc trò chuyện thực tế trong tài khoản của bạn.</p></div></div>{events.length ? <div className="settings-list">{events.map((item) => <Link className="settings-row" href={item.kind === "analysis" ? `/my-analyses/${item.id}` : `/chat?id=${item.id}`} key={`${item.kind}-${item.id}`}><span className="settings-row-icon">{item.kind === "analysis" ? <BookOpenCheck size={17} /> : <MessageSquareText size={17} />}</span><span className="settings-row-copy"><strong>{item.title}</strong><small>{item.kind === "analysis" ? "Bản nháp phân tích" : "Cuộc trò chuyện"} · {new Intl.DateTimeFormat("vi-VN", { dateStyle: "medium" }).format(new Date(item.updated_at))}</small></span><ArrowRight size={15} color="#9ba6b3" /></Link>)}</div> : <section className="card-surface empty-state"><span className="empty-state-icon"><BookOpenCheck size={19} /></span><strong>Lịch sử của bạn đang trống</strong><p>Hoạt động nghiên cứu sẽ được ghi lại tại đây khi bạn lưu bản nháp hoặc câu hỏi.</p></section>}</div>
}
