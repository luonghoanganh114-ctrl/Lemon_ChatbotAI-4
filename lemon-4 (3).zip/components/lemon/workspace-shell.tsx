"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState, type FormEvent, type ReactNode } from "react"
import {
  BookOpen, BookOpenCheck, BadgeCheck, ChevronLeft, ChevronRight, CircleHelp,
  GitCompareArrows, History, Home, Library, LogOut, Menu, MessageSquareText,
  Moon, Search, Settings, ShieldCheck, Sparkles, Sun, UserRound, Users, X, Scale, ClipboardCheck,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"

type SessionUser = { id: string; email: string; name: string; avatarUrl: string | null }

const navItems = [
  { label: "Tổng quan", href: "/dashboard", icon: Home, group: "Không gian" },
  { label: "Chat với Lemon", href: "/chat", icon: MessageSquareText, group: "Không gian" },
  { label: "Phân tích tác phẩm", href: "/tools/analysis", icon: BookOpenCheck, group: "Ghi chú" },
  { label: "Nghiên cứu tác giả", href: "/tools/author", icon: Users, group: "Ghi chú" },
  { label: "So sánh văn học", href: "/tools/compare", icon: GitCompareArrows, group: "Ghi chú" },
  { label: "Phản biện học thuật", href: "/tools/critique", icon: Scale, group: "Ghi chú" },
  { label: "Kiểm chứng dẫn chứng", href: "/tools/verify", icon: BadgeCheck, group: "Ghi chú" },
  { label: "Test năng lực Ngữ văn", href: "/tools/competency-test", icon: ClipboardCheck, group: "Ghi chú" },
  { label: "Thư viện văn học", href: "/library", icon: Library, group: "Tri thức" },
  { label: "Lịch sử nghiên cứu", href: "/history", icon: History, group: "Tri thức" },
]

function Brand({ collapsed = false }: { collapsed?: boolean }) {
  return <Link href="/dashboard" className={`brand-lockup${collapsed ? " brand-collapsed" : ""}`} aria-label="LEMON — Tổng quan">
    <span className="brand-mark"><BookOpen size={20} strokeWidth={2.1} /></span>
    {!collapsed && <span className="brand-word">LEMON<span className="brand-dot">.</span></span>}
  </Link>
}

export function WorkspaceShell({ children, user }: { children: ReactNode; user: SessionUser }) {
  const pathname = usePathname()
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [dark, setDark] = useState(false)
  const initial = (user.name.trim()[0] || user.email[0] || "L").toUpperCase()

  async function signOut() {
    if (!window.confirm("Bạn muốn đăng xuất khỏi Lemon?")) return
    await createClient().auth.signOut()
    router.replace("/")
    router.refresh()
  }

  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const query = String(data.get("query") ?? "").trim()
    if (query) router.push(`/my-analyses?query=${encodeURIComponent(query)}`)
  }

  function toggleTheme() {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle("dark", next)
  }

  const sidebar = (
    <aside className={`workspace-sidebar${collapsed ? " is-collapsed" : ""}${mobileOpen ? " mobile-open" : ""}`}>
      <div className="sidebar-brand-row"><Brand collapsed={collapsed} /><button className="icon-button mobile-close" type="button" aria-label="Đóng menu" onClick={() => setMobileOpen(false)}><X size={19} /></button></div>
      <div className="sidebar-scroll">
        {["Không gian", "Ghi chú", "Tri thức"].map((group) => (
          <div className="nav-group" key={group}>
            {!collapsed && <p className="nav-group-label">{group}</p>}
            <nav aria-label={group}>
              {navItems.filter((item) => item.group === group).map(({ label, href, icon: Icon }) => {
                const active = pathname === href || (href.startsWith("/tools/") && pathname === href)
                return <Link key={href} href={href} title={collapsed ? label : undefined} onClick={() => setMobileOpen(false)} className={`sidebar-link${active ? " active" : ""}`} aria-current={active ? "page" : undefined}>
                  <Icon size={19} strokeWidth={active ? 2.3 : 1.8} /><span>{label}</span>{active && <span className="nav-active-mark" />}
                </Link>
              })}
            </nav>
          </div>
        ))}
      </div>
      <div className="sidebar-footer">
        <Link href="/settings" className={`sidebar-link${pathname === "/settings" ? " active" : ""}`} title={collapsed ? "Cài đặt" : undefined} onClick={() => setMobileOpen(false)}><Settings size={19} /><span>Cài đặt</span></Link>
        {!collapsed && <div className="sidebar-help"><span className="help-icon"><CircleHelp size={16} /></span><div><strong>Cần hỗ trợ?</strong><small>Chat với trợ lý Lemon</small></div><Sparkles size={15} className="help-sparkle" /></div>}
        <button className="collapse-button" type="button" onClick={() => setCollapsed((value) => !value)} aria-label={collapsed ? "Mở rộng thanh bên" : "Thu gọn thanh bên"}>
          {collapsed ? <ChevronRight size={17} /> : <><ChevronLeft size={17} /><span>Thu gọn menu</span></>}
        </button>
      </div>
    </aside>
  )

  return (
    <div className={`workspace-root${collapsed ? " sidebar-collapsed" : ""}`}>
      {sidebar}
      {mobileOpen && <button className="mobile-scrim" aria-label="Đóng menu" type="button" onClick={() => setMobileOpen(false)} />}
      <div className="workspace-main">
        <header className="workspace-topbar">
          <button className="icon-button mobile-menu" type="button" onClick={() => setMobileOpen(true)} aria-label="Mở menu"><Menu size={21} /></button>
          <div className="breadcrumb"><span>Không gian nghiên cứu</span><ChevronRight size={14} /><strong>{navItems.find((item) => item.href === pathname)?.label || (pathname.includes("my-analyses") ? "Bài phân tích của tôi" : pathname.includes("profile") ? "Hồ sơ cá nhân" : pathname.includes("settings") ? "Cài đặt" : "Lemon")}</strong></div>
          <div className="topbar-actions">
            <form className="global-search" role="search" onSubmit={submitSearch}>
              <Search size={16} /><input aria-label="Tìm trong bài phân tích đã lưu" name="query" placeholder="Tìm nghiên cứu của bạn" /><kbd>⌘ K</kbd>
            </form>
            <button className="icon-button theme-toggle" type="button" aria-label={dark ? "Bật giao diện sáng" : "Bật giao diện tối"} onClick={toggleTheme}>{dark ? <Sun size={18} /> : <Moon size={18} />}</button>
            <div className="account-menu-wrap">
              <button className="account-trigger" type="button" onClick={() => setProfileOpen((value) => !value)} aria-expanded={profileOpen} aria-label="Mở menu tài khoản">
                {user.avatarUrl ? <img src={user.avatarUrl} alt="" className="avatar-image" /> : <span className="avatar-fallback">{initial}</span>}
                <span className="account-trigger-copy"><strong>{user.name}</strong><small>Không gian cá nhân</small></span>
                <ChevronRight className="account-chevron" size={15} />
              </button>
              {profileOpen && <div className="account-dropdown" role="menu">
                <div className="dropdown-identity"><strong>{user.name}</strong><small>{user.email}</small></div>
                <Link href="/profile" role="menuitem" onClick={() => setProfileOpen(false)}><UserRound size={16} /> Hồ sơ cá nhân</Link>
                <Link href="/my-analyses" role="menuitem" onClick={() => setProfileOpen(false)}><BookOpenCheck size={16} /> Bài phân tích đã lưu</Link>
                <Link href="/my-conversations" role="menuitem" onClick={() => setProfileOpen(false)}><MessageSquareText size={16} /> Lịch sử trò chuyện</Link>
                <Link href="/settings/security" role="menuitem" onClick={() => setProfileOpen(false)}><ShieldCheck size={16} /> Bảo mật</Link>
                <button role="menuitem" type="button" onClick={signOut}><LogOut size={16} /> Đăng xuất</button>
              </div>}
            </div>
          </div>
        </header>
        <main className="workspace-content">{children}</main>
        <footer className="workspace-footer"><span>LEMON · Nền tảng nghiên cứu văn học</span><span>Chạm vào tri thức — Khám phá chiều sâu văn học.</span></footer>
      </div>
    </div>
  )
}
