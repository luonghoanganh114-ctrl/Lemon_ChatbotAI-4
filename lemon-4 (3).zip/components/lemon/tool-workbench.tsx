"use client"

import Link from "next/link"
import { useState, type FormEvent } from "react"
import { ArrowRight, BadgeCheck, BookOpenCheck, Check, CircleHelp, GitCompareArrows, LoaderCircle, Save, Scale, Sparkles, Users } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

const tools = {
  analysis: {
    title: "Ghi chú tác phẩm", eyebrow: "LITERATURE NOTES", description: "Lưu lại những điều bạn muốn ghi nhớ về tác phẩm.", icon: BookOpenCheck,
    primaryLabel: "Tên tác phẩm", primaryPlaceholder: "Ví dụ: tên tác phẩm bạn đang đọc", secondaryLabel: "Tác giả", secondaryPlaceholder: "Tên tác giả (nếu biết)", noteLabel: "Phần cần lưu ý", notePlaceholder: "Ghi lại câu hỏi, ý tưởng hoặc điều bạn muốn lưu ý…", mode: "basic",
    sections: ["Thông tin và bối cảnh", "Tóm tắt nội dung", "Chủ đề và tư tưởng", "Nhân vật và hình tượng", "Ngôn ngữ và nghệ thuật", "Giá trị hiện thực", "Giá trị nhân đạo", "Nhận định tổng hợp"],
  },
  author: {
    title: "Ghi chú tác giả", eyebrow: "AUTHOR NOTES", description: "Lưu lại những điều cần nhớ về cuộc đời, phong cách và bối cảnh sáng tác.", icon: Users,
    primaryLabel: "Tên tác giả", primaryPlaceholder: "Nhập tên tác giả", secondaryLabel: "Thời kỳ / quốc gia", secondaryPlaceholder: "Tùy chọn", noteLabel: "Tiểu sử", notePlaceholder: "Ghi chú thông tin tiểu sử của tác giả này…", mode: "advanced",
    sections: ["Tiểu sử và bối cảnh", "Sự nghiệp sáng tác", "Phong cách", "Quan niệm nghệ thuật", "Tác phẩm tiêu biểu", "Đóng góp văn học"],
  },
  compare: {
    title: "Ghi chú so sánh", eyebrow: "LITERARY NOTES", description: "Lưu lại các điểm cần ghi chú khi đặt hai tác phẩm cạnh nhau.", icon: GitCompareArrows,
    primaryLabel: "Tác phẩm thứ nhất", primaryPlaceholder: "Tên tác phẩm thứ nhất", secondaryLabel: "Tác phẩm thứ hai", secondaryPlaceholder: "Tên tác phẩm thứ hai", noteLabel: "Tiêu chí / ghi chú", notePlaceholder: "Bối cảnh, chủ đề, nhân vật, ngôn ngữ, phong cách…", mode: "advanced",
    sections: ["Bối cảnh lịch sử", "Chủ đề và tư tưởng", "Hình tượng nhân vật", "Xung đột", "Nghệ thuật và ngôn ngữ", "Điểm tương đồng", "Điểm khác biệt"],
  },
  critique: {
    title: "Phản biện học thuật", eyebrow: "ACADEMIC CRITIQUE", description: "Lưu một luận điểm cần xem xét. Lemon không mặc định luận điểm đúng hoặc sai và chưa tạo phản biện khi AI chưa kết nối.", icon: Scale,
    primaryLabel: "Luận điểm cần phản biện", primaryPlaceholder: "Nhập nhận định hoặc luận điểm văn học", secondaryLabel: "Tác phẩm / bối cảnh", secondaryPlaceholder: "Tùy chọn", noteLabel: "Nguồn hoặc ghi chú", notePlaceholder: "Ghi lại dữ kiện, nguồn tham khảo hoặc điều bạn còn băn khoăn…", mode: "academic",
    sections: ["Xác định luận đề", "Phân tích tiền đề", "Luận cứ ủng hộ", "Luận cứ phản bác", "Cách diễn giải thay thế", "Đánh giá lập luận", "Kết luận"],
  },
  verify: {
    title: "Kiểm chứng dẫn chứng", eyebrow: "SOURCE VERIFICATION", description: "Ghi lại trích dẫn cần kiểm tra. Lemon không đánh dấu xác minh nếu chưa tra cứu nguồn đáng tin cậy.", icon: BadgeCheck,
    primaryLabel: "Câu trích dẫn / nhận định", primaryPlaceholder: "Dán câu thơ, câu văn hoặc nhận định cần kiểm chứng", secondaryLabel: "Tác phẩm / tác giả", secondaryPlaceholder: "Tùy chọn", noteLabel: "Thông tin nguồn bạn có", notePlaceholder: "Ấn bản, trang sách, đường dẫn hoặc ghi chú…", mode: "academic",
    sections: ["Đối chiếu nguyên văn", "Tác phẩm và tác giả", "Dị bản / bản dịch", "Nguồn xác minh", "Trạng thái kiểm chứng"],
  },
} as const

type ToolKey = keyof typeof tools

export function ToolWorkbench({ tool }: { tool: string }) {
  const toolKey = (tool in tools ? tool : "analysis") as ToolKey
  const config = tools[toolKey]
  const Icon = config.icon
  const [primary, setPrimary] = useState("")
  const [secondary, setSecondary] = useState("")
  const [notes, setNotes] = useState("")
  const [selected, setSelected] = useState<string[]>([...config.sections])
  const [saving, setSaving] = useState(false)
  const [savedId, setSavedId] = useState<string | null>(null)
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null)

  async function saveDraft(event?: FormEvent<HTMLFormElement>, silent = false) {
    event?.preventDefault()
    if (!primary.trim() && !notes.trim()) {
      if (!silent) setNotice({ tone: "error", text: "Hãy nhập ít nhất một tên hoặc ghi chú trước khi lưu." })
      return
    }
    setSaving(true)
    setNotice(null)
    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại để lưu bản nháp.")
      const workTitle = primary.trim()
      const payload = {
        user_id: user.id,
        title: `${config.title}: ${workTitle || "Bản nháp"}`.slice(0, 180),
        work_title: workTitle,
        author_name: secondary.trim(),
        analysis_mode: config.mode,
        content: { draft_text: notes.trim(), secondary_input: secondary.trim(), selected_sections: selected, status: "draft", ai_status: "not_connected" },
        tags: [toolKey, "draft"],
        updated_at: new Date().toISOString(),
      }
      const result = savedId
        ? await supabase.from("saved_analyses").update(payload).eq("id", savedId).eq("user_id", user.id).select("id").single()
        : await supabase.from("saved_analyses").insert(payload).select("id").single()
      if (result.error) throw new Error("Không thể lưu bản nháp. Vui lòng thử lại.")
      setSavedId(result.data.id)
      if (!silent) setNotice({ tone: "success", text: "Bản nháp đã được lưu trong thư viện cá nhân." })
    } catch (error) {
      if (!silent) setNotice({ tone: "error", text: error instanceof Error ? error.message : "Không thể lưu bản nháp." })
    } finally {
      setSaving(false)
    }
  }

  function toggleSection(section: string) {
    setSelected((current) => current.includes(section) ? current.filter((item) => item !== section) : [...current, section])
  }

  return (
    <div>
      <div className="page-heading">
        <div><span className="page-kicker">{config.eyebrow}</span><h1>{config.title}</h1><p>{config.description}</p></div>
        {savedId && <Link className="button button-quiet button-small" href={`/my-analyses/${savedId}`}>Mở bản nháp <ArrowRight size={14} /></Link>}
      </div>
      <div className="tool-layout">
        <section className="tool-form-card card-surface">
          <div className="card-heading"><div><h2>Ghi chú</h2><p>Thông tin bạn nhập sẽ được lưu riêng theo tài khoản.</p></div><span className="feature-icon green" style={{ width: 34, height: 34, marginBottom: 0 }}><Icon size={17} /></span></div>
          <form className="tool-form" onSubmit={(event) => saveDraft(event)}>
            <label className="form-field"><span>{config.primaryLabel}</span><input className="text-input" value={primary} onChange={(event) => setPrimary(event.target.value)} onBlur={() => { if (savedId && primary.trim()) void saveDraft(undefined, true) }} maxLength={240} placeholder={config.primaryPlaceholder} /></label>
            <label className="form-field"><span>{config.secondaryLabel}</span><input className="text-input" value={secondary} onChange={(event) => setSecondary(event.target.value)} maxLength={240} placeholder={config.secondaryPlaceholder} /></label>
            <label className="form-field"><span className="form-label-row"><span>{config.noteLabel}</span><small>{notes.length}/4000</small></span><textarea className="textarea-input" value={notes} onChange={(event) => setNotes(event.target.value)} onBlur={() => { if (savedId && notes.trim()) void saveDraft(undefined, true) }} maxLength={4000} placeholder={config.notePlaceholder} /></label>
            <div className="tool-submit-row">
              <button className="button button-primary" type="submit" disabled={saving}>{saving ? <LoaderCircle className="spin" size={16} /> : <Save size={16} />}{saving ? "Đang lưu…" : savedId ? "Cập nhật bản nháp" : "Lưu vào thư viện cá nhân"}</button>
            </div>
            {notice && <p className={`form-notice ${notice.tone}`} role="status">{notice.text}</p>}
          </form>
        </section>
        <aside className="dashboard-column">
          <section className="tool-side-card card-surface">
            <div className="card-heading"><div><h3>Phần cần lưu ý</h3><p>Chọn những mục bạn muốn lưu trong ghi chú.</p></div><CircleHelp size={16} color="#9ba6b3" /></div>
            <ul className="tool-section-list">{config.sections.map((section) => <li key={section}><input type="checkbox" checked={selected.includes(section)} onChange={() => toggleSection(section)} aria-label={`Chọn ${section}`} /><span>{section}</span></li>)}</ul>
          </section>
          <section className="api-status-card">
            <div className="api-status-header"><span><Sparkles size={15} /></span> Trạng thái tích hợp</div>
            <p><strong>Chế độ ghi chú.</strong> Nội dung được lưu vào thư viện cá nhân theo tài khoản của bạn.</p>
          </section>
          <div className="muted-note">Bản nháp được lưu khi bạn chọn lưu. Thay đổi tiếp theo được đồng bộ khi rời khỏi trường nhập liệu.</div>
        </aside>
      </div>

    </div>
  )
}
