"use client"

import Link from "next/link"
import { useState, type FormEvent } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Eye, EyeOff, Leaf, LoaderCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

type AuthMode = "login" | "register" | "forgot" | "reset"

const copy: Record<AuthMode, { eyebrow: string; title: string; description: string; action: string }> = {
  login: { eyebrow: "Chào mừng trở lại", title: "Đăng nhập Lemon", description: "Tiếp tục hành trình nghiên cứu của bạn.", action: "Đăng nhập" },
  register: { eyebrow: "Bắt đầu hành trình", title: "Tạo tài khoản", description: "Một không gian nghiên cứu riêng, lưu lại mọi khám phá.", action: "Tạo tài khoản" },
  forgot: { eyebrow: "Khôi phục truy cập", title: "Quên mật khẩu?", description: "Nhập email đăng ký để nhận liên kết đặt lại mật khẩu.", action: "Gửi liên kết" },
  reset: { eyebrow: "Cập nhật bảo mật", title: "Đặt mật khẩu mới", description: "Chọn mật khẩu mạnh để bảo vệ không gian nghiên cứu.", action: "Cập nhật mật khẩu" },
}

export function AuthPanel({ mode }: { mode: AuthMode }) {
  const router = useRouter()
  const [busy, setBusy] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [notice, setNotice] = useState<{ tone: "error" | "success"; text: string } | null>(null)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setNotice(null)
    setBusy(true)
    const form = new FormData(event.currentTarget)
    const email = String(form.get("email") ?? "").trim().toLowerCase()
    const password = String(form.get("password") ?? "")
    const confirmation = String(form.get("confirmation") ?? "")
    const fullName = String(form.get("fullName") ?? "").trim()

    try {
      const supabase = createClient()
      if (mode === "register") {
        if (password.length < 8) throw new Error("Mật khẩu cần có ít nhất 8 ký tự.")
        if (password !== confirmation) throw new Error("Hai mật khẩu chưa trùng khớp.")
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
          },
        })
        if (error) throw new Error("Không thể tạo tài khoản. Hãy kiểm tra thông tin hoặc thử đăng nhập nếu bạn đã có tài khoản.")
        router.replace("/register/success")
        router.refresh()
        return
      }

      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) {
          const lower = error.message.toLowerCase()
          throw new Error(lower.includes("not confirmed") || lower.includes("confirm your email") ? "Email chưa được xác nhận. Hãy mở liên kết xác nhận trong hộp thư." : "Email hoặc mật khẩu không chính xác.")
        }
        const next = new URLSearchParams(window.location.search).get("next")
        const safeNext = next?.startsWith("/") && !next.startsWith("//") ? next : "/dashboard"
        router.replace(safeNext)
        router.refresh()
        return
      }

      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth/callback?next=%2Freset-password`,
        })
        if (error) throw new Error("Không gửi được yêu cầu lúc này. Vui lòng thử lại sau.")
        setNotice({ tone: "success", text: "Nếu địa chỉ này có tài khoản Lemon, email hướng dẫn khôi phục sẽ được gửi đến hộp thư." })
        return
      }

      if (password.length < 8) throw new Error("Mật khẩu mới cần có ít nhất 8 ký tự.")
      if (password !== confirmation) throw new Error("Hai mật khẩu chưa trùng khớp.")
      const { error } = await supabase.auth.updateUser({ password })
      if (error) throw new Error("Liên kết có thể đã hết hạn. Hãy yêu cầu email khôi phục mới.")
      setNotice({ tone: "success", text: "Mật khẩu đã được cập nhật." })
      window.setTimeout(() => router.replace("/login"), 900)
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Đã có lỗi xảy ra. Vui lòng thử lại." })
    } finally {
      setBusy(false)
    }
  }

  const config = copy[mode]
  const needsEmail = mode !== "reset"
  const needsPassword = mode === "login" || mode === "register" || mode === "reset"

  return (
    <main className="auth-shell">
      <div className="auth-backdrop" aria-hidden="true" />
      <section className="auth-card" aria-labelledby="auth-title">
        <Link className="auth-brand" href="/" aria-label="Lemon, về trang chủ">
          <span className="brand-mark"><Leaf size={20} strokeWidth={2.4} /></span>
          <span>LEMON<span className="brand-dot">.</span></span>
        </Link>
        <div className="auth-heading">
          <span className="eyebrow">{config.eyebrow}</span>
          <h1 id="auth-title">{config.title}</h1>
          <p>{config.description}</p>
        </div>
        <form className="auth-form" onSubmit={handleSubmit}>
          {mode === "register" && (
            <label className="form-field">
              <span>Họ và tên</span>
              <input name="fullName" autoComplete="name" minLength={2} maxLength={80} required placeholder="Nguyễn Minh An" />
            </label>
          )}
          {needsEmail && (
            <label className="form-field">
              <span>Email</span>
              <input name="email" type="email" autoComplete="email" required placeholder="ban@example.com" />
            </label>
          )}
          {needsPassword && (
            <>
              <label className="form-field">
                <span>{mode === "reset" ? "Mật khẩu mới" : "Mật khẩu"}</span>
                <span className="password-control">
                  <input name="password" type={showPassword ? "text" : "password"} minLength={8} autoComplete={mode === "login" ? "current-password" : "new-password"} required placeholder="Tối thiểu 8 ký tự" />
                  <button type="button" className="icon-button password-toggle" aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"} onClick={() => setShowPassword((value) => !value)}>
                    {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                  </button>
                </span>
              </label>
              {(mode === "register" || mode === "reset") && (
                <label className="form-field">
                  <span>Xác nhận mật khẩu</span>
                  <input name="confirmation" type={showPassword ? "text" : "password"} minLength={8} autoComplete="new-password" required placeholder="Nhập lại mật khẩu" />
                </label>
              )}
            </>
          )}
          {mode === "register" && (
            <label className="terms-row">
              <input name="terms" type="checkbox" required />
              <span>Tôi đồng ý với <a href="#terms">Điều khoản sử dụng</a> và <a href="#privacy">Chính sách bảo mật</a>.</span>
            </label>
          )}
          {mode === "login" && <div className="auth-inline-link"><Link href="/forgot-password">Quên mật khẩu?</Link></div>}
          {notice && <p className={`form-notice ${notice.tone}`} role="status">{notice.text}</p>}
          <button className="button button-primary auth-submit" type="submit" disabled={busy}>
            {busy ? <LoaderCircle className="spin" size={17} /> : null}
            {busy ? "Đang xử lý…" : config.action}
          </button>
        </form>
        <div className="auth-switch">
          {mode === "login" && <>Chưa có tài khoản? <Link href="/register">Tạo tài khoản</Link></>}
          {mode === "register" && <>Đã có tài khoản? <Link href="/login">Đăng nhập</Link></>}
          {mode === "forgot" && <Link href="/login"><ArrowLeft size={15} /> Quay lại đăng nhập</Link>}
          {mode === "reset" && notice?.tone === "success" && <Link href="/login">Đến trang đăng nhập</Link>}
        </div>
        <p className="auth-footnote">Tài khoản được bảo vệ bởi Supabase Auth. Lemon không lưu mật khẩu của bạn.</p>
      </section>
      <div className="auth-aside">
        <div className="aside-orbit orbit-one" />
        <div className="aside-orbit orbit-two" />
        <div className="aside-content">
          <span className="aside-kicker">Không gian nghiên cứu của bạn</span>
          <h2>Đọc sâu hơn.<br /><em>Nghĩ rộng hơn.</em></h2>
          <p>Lưu lại những câu hỏi hay, kết nối các ý tưởng và quay lại đúng nơi bạn đã dừng.</p>
          <div className="aside-note"><span className="aside-note-icon"><Leaf size={18} /></span><span>Chạm vào tri thức<br /><strong>Khám phá chiều sâu văn học.</strong></span></div>
        </div>
      </div>
    </main>
  )
}
