import type { Metadata } from "next"
import { AuthPanel } from "@/components/lemon/auth-panel"

export const metadata: Metadata = { title: "Đặt lại mật khẩu" }

export default function ResetPasswordPage() {
  return <AuthPanel mode="reset" />
}
