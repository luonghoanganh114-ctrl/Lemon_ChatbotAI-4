import type { Metadata } from "next"
import { AuthPanel } from "@/components/lemon/auth-panel"

export const metadata: Metadata = { title: "Khôi phục mật khẩu" }

export default function ForgotPasswordPage() {
  return <AuthPanel mode="forgot" />
}
