import { generateText } from "ai"
import { gateway } from "@ai-sdk/gateway"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json() as { tool?: string; workTitle?: string; author?: string; mode?: string; sections?: string[]; notes?: string }
    const workTitle = body.workTitle?.trim()
    if (!workTitle) return NextResponse.json({ error: "Vui lòng nhập thông tin nghiên cứu." }, { status: 400 })
    if (body.tool === "compare" && !body.author?.trim()) return NextResponse.json({ error: "Vui lòng nhập tên tác phẩm thứ hai." }, { status: 400 })

    const prompts: Record<string, string> = {
      analysis: `Phân tích tác phẩm “${workTitle}” của tác giả “${body.author?.trim() || "chưa rõ"}”`,
      author: `Nghiên cứu toàn diện tác giả “${workTitle}”, gồm năm sinh - năm mất (nếu có), quê quán, gia đình và học vấn khi có thông tin đáng tin cậy, bối cảnh sống, sự nghiệp, phong cách, quan niệm nghệ thuật, tác phẩm tiêu biểu và đóng góp`,
      compare: `So sánh và phân tích hai tác phẩm “${workTitle}” và “${body.author?.trim()}”`,
      critique: `Phản biện học thuật luận điểm “${workTitle}” trong bối cảnh “${body.author?.trim() || "chưa rõ"}`,
      verify: `Kiểm chứng dẫn chứng hoặc nhận định “${workTitle}” liên quan đến “${body.author?.trim() || "chưa rõ"}`,
    }

    const result = await generateText({
      model: gateway("anthropic/claude-sonnet-4.6"),
      system: "Bạn là Lemon, trợ lý nghiên cứu Ngữ văn bằng tiếng Việt. Viết chính xác, mạch lạc, phân biệt rõ dữ kiện với diễn giải. Nếu không chắc chi tiết tác phẩm, hãy nói rõ và không bịa trích dẫn.",
      prompt: `${prompts[body.tool || "analysis"] || prompts.analysis}. Chế độ nghiên cứu: ${body.mode || "Cơ bản"}. Các mục cần có: ${(body.sections || []).join(", ")}. Ghi chú của người học: ${body.notes?.trim() || "không có"}.\n\nTrình bày bằng tiếng Việt, có tiêu đề và các mục rõ ràng. Với thông tin tiểu sử hoặc dữ kiện không chắc chắn, hãy ghi chú “chưa xác minh” thay vì bịa đặt. Với so sánh, nêu cả điểm tương đồng, khác biệt và nhận xét tổng hợp.`
    })

    return NextResponse.json({ content: result.text })
  } catch {
    return NextResponse.json({ error: "Lemon chưa thể tạo kết quả lúc này. Vui lòng thử lại." }, { status: 500 })
  }
}
