import { redirect } from "next/navigation"
import { MarketingHome } from "@/components/lemon/marketing-home"
import { createClient } from "@/lib/supabase/server"

export default async function HomePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (user) redirect("/dashboard")
  return <MarketingHome />
}
