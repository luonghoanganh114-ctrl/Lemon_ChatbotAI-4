import { redirect } from "next/navigation"
import { WorkspaceShell } from "@/components/lemon/workspace-shell"
import { createClient } from "@/lib/supabase/server"

export default async function WorkspaceLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect("/login?next=%2Fdashboard")

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, avatar_url")
    .eq("id", user.id)
    .maybeSingle()

  let avatarUrl: string | null = null
  if (profile?.avatar_url) {
    const { data } = await supabase.storage.from("lemon-avatars").createSignedUrl(profile.avatar_url, 60 * 15)
    avatarUrl = data?.signedUrl ?? null
  }

  return (
    <WorkspaceShell
      user={{
        id: user.id,
        email: user.email ?? "",
        name: profile?.full_name || user.user_metadata?.full_name || "Nhà nghiên cứu",
        avatarUrl,
      }}
    >
      {children}
    </WorkspaceShell>
  )
}
